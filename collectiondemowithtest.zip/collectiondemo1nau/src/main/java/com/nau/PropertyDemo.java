package com.nau;

import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertyDemo {
	public static void main(String[] args) {
		// writrePropertyFile();
		readPropertyFile();
	}

	private static void readPropertyFile() {
		Properties p1 = new Properties();
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		InputStream is = loader.getResourceAsStream("myinfo.properties");
		try {
			p1.load(is);
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println(p1.getProperty("name"));
		System.out.println(p1.getProperty("pin"));
	}

	private static void writrePropertyFile() {
		Properties p1 = new Properties();
		System.out.println(p1.put("name", "naushad"));
		System.out.println(p1.put("city", "Mumbai"));
		System.out.println(p1.put("city", "Pune"));
		try (FileWriter fw = new FileWriter("myinfo.properties")) {
			p1.store(fw, "Info File");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
