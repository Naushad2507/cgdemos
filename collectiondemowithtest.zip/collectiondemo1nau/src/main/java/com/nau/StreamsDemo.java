package com.nau;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Flow.Processor;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.nau.model.Employee;

public class StreamsDemo {
	public static void main(String[] args) {
		
		
		int t = Runtime.getRuntime().availableProcessors();
		System.out.println(t);
		Employee e1 = new Employee(2, "naushad");
		Employee e2 = new Employee(3, "akhtar");
		Employee e3 = new Employee(1, "rahul");
		Employee e4 = new Employee(4, "nakul");
		List<Employee> employees = new ArrayList<>();
		employees.add(e1);
		employees.add(e2);
		employees.add(e3);
		employees.add(e4);
		//employees.forEach(e -> System.out.println(e.getId() + "\t" + e.getName()));

		List<Employee> c= employees.parallelStream()
				.filter(e->e.getName().startsWith("n"))
				.toList();
		
		System.out.println(c);
	
		
		
		//System.out.println(c);
//		for (Employee e : employees) {
//			System.out.println(e.getId() + "\t" + e.getName());
//		}

	}
}
