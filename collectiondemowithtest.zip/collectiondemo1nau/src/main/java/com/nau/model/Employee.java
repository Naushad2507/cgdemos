package com.nau.model;

import java.util.Objects;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Employee{
	private int id;
	private String name;
	
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		return id == other.id;
	}
//	@Override
//	public int compareTo(Employee o) {
//		return this.getId() - o.getId();
//	}
//	@Override
//	public int compareTo(Employee o) {
//		return this.getName().compareTo(o.getName());
//	}
//	
	
}
