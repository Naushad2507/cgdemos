package com.nau;

import java.util.Comparator;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

import com.nau.model.Employee;

public class EmployeeAssignmentSortedSet {
//	private static class SortByName implements Comparator<Employee>{
//		@Override
//		public int compare(Employee o1, Employee o2) {
//			return o1.getName().compareTo(o2.getName());
//		}
//	}
	private static Set<Employee> employees = new TreeSet<>((e1,e2)->e1.getName().compareTo(e2.getName()));
	private static Scanner scanner = new Scanner(System.in);
	public static void main(String[] args) {
		options();
	}
	private static void options() {
		System.out.println("Enter Option : ");
		System.out.println("1 . Add Employees ");
		System.out.println("2. Display Employees");
		System.out.println("3. Update Employee"); // update name of said id
		System.out.println("4. View Employee"); // ask for id
		System.out.println("5. Delete Emloyee"); // ask for id
		System.out.println("6. Exit");
		int option = scanner.nextInt();
		switch (option) {
		case 1: {
			addEmployees();
			options();
			break;
		}
		case 2: {
			displayEmployees();
			options();
			break;
		}
		
		case 6: {
			System.out.println("Thank you for using the app, Good Bye");
			System.exit(0);
			break;
		}
		default:
			System.out.println("Invlaid Options");
			options();
		}
	}

	private static void addEmployees() {
		for (;;) {
			System.out.println("Enter Id : ");
			int id = scanner.nextInt();
			System.out.println("Enter Name");
			String name = scanner.next();
			Employee employee = new Employee(id, name);
			boolean res =employees.add(employee);
			if(!res) {
				System.out.println("Emp with id " + id + " already exists");
			}
			System.out.println("Do you want to add more Y/N ");
			String ans = scanner.next();
			if (ans.equalsIgnoreCase("y")) {
			} else {
				options();
				break;
			}
		}
	}
	private static void displayEmployees() {
		employees.forEach((e) -> {
			System.out.println(e.getId() + "\t" + e.getName());
		});
	}

}
