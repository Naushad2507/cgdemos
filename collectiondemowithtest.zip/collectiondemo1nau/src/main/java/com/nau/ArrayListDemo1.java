package com.nau;

import java.util.ArrayList;

import com.nau.model.Employee;

public class ArrayListDemo1 {
	
	public static void main(String[] args) {
		Employee e = new Employee();
		e.setId(11);
		e.setName("akhtar11");
		Employee e1 = new Employee(1,"akhtar1");
		Employee e2 = new Employee(2,"akhtar2");
		Employee e3 = new Employee(3,"akhtar3");
		Employee e4 = new Employee(4,"akhtar4");
		Employee e5 = new Employee(5,"akhtar5");
		
		ArrayList<Employee> employees = new ArrayList<>();
		employees.add(e);
		employees.add(e1);
		employees.add(e2);
		employees.add(e3);
		employees.add(e4);
		employees.add(e5);
		employees.forEach(System.out::println);
		System.out.println("==========================");
		employees.set(1, new Employee(11,"akhtar11"));
		employees.forEach(System.out::println);
		
		
		// Take 2 values from user :   id and name;
		// store  them in collection objects.
		// enter till no is said
		// display all employees added
		
	}

}
