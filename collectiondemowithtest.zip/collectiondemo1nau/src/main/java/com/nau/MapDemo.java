package com.nau;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.function.BiConsumer;

public class MapDemo {
	public static void main(String[] args) {
		Vector<String> v1 = new Vector<>(6, 2); // synchronized
		ArrayList<String> al;
		StringBuilder sb;
		StringBuffer sbu; // synchronized
		// Map<Integer , String> studentData1 = new Hashtable<>();// synchronized

		Map<String, String> studentData = new HashMap<>();
		
		System.out.println(studentData.put("2", "Rahul"));
		studentData.put("3", "akhtar");
		studentData.put("4", "nakul");
		// System.out.println(studentData.put(3, "Akhtar"));
	//	Collection<String> ss =  studentData.values();
	//	ss.forEach(s->System.out.println(s.toUpperCase()));
		//studentData.forEach((k,v)->System.out.println(k+ " " + v));
		studentData.entrySet()
		.stream()
		.filter(e->e.getValue().startsWith("n"))
		.forEach(ss->System.out.println(ss));
		
		
//		BiConsumer<Integer, String> bi = new BiConsumer<Integer, String>() {
//			@Override
//			public void accept(Integer t, String u) {
//				System.out.println(t + "\t" + u);
//			}
//		};
//
//		 studentData.forEach((k,v)->System.out.println(k + "\t" + v));
//		
//		Set<Integer> set = studentData.keySet();
//		for (Integer i : set) {
//			String name = studentData.get(i);
//			System.out.println(name);
//		}
	}
}
