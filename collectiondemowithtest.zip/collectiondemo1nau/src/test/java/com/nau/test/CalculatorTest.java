package com.nau.test;



import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.nau.Calculator;


public class CalculatorTest {

	@Test
	public void testAdd() {
		Calculator calculator = new Calculator();
		int res = calculator.add(3, 5);
		assertEquals(6, res);
	}

}
