package com.nau;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import com.nau.model.Employee;

public class EmployeeAssignmentSet {
	private static Set<Employee> employees = new HashSet<>();
	private static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		options();
	}
	private static void options() {
		System.out.println("Enter Option : ");
		System.out.println("1 . Add Employees ");
		System.out.println("2. Dispplay Emloyees");
		System.out.println("3. Exit");
		int option = scanner.nextInt();
		switch (option) {
		case 1: {
			addEmployees();
			options();
			break;
		}
		case 2: {
			displayEmployees();
			options();
			break;
		}
		case 3: {
			System.out.println("Thank you for using the app, Good Bye");
			System.exit(0);
			break;
		}
		default:
			System.out.println("Invlaid Options");
			options();
		}
	}

	private static void addEmployees() {
		for (;;) {
			System.out.println("Enter Id : ");
			int id = scanner.nextInt();
			System.out.println("Enter Name");
			String name = scanner.next();
			Employee employee = new Employee(id, name);
			boolean res =employees.add(employee);
			if(!res) {
				System.out.println("Emp with id " + id + " already exists");
			}
			System.out.println("Do you want to add more Y/N ");
			String ans = scanner.next();
			if (ans.equalsIgnoreCase("y")) {
			} else {
				options();
				break;
			}
		}
	}
	private static void displayEmployees() {
		employees.forEach((e) -> {
			System.out.println(e.getId() + "\t" + e.getName());
		});
	}

}
