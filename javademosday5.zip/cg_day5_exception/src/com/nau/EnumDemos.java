package com.nau;
interface Week {
	int day();
}

enum Day implements Week{
	Monday,
	Tuesday;
	
	@Override
	public int day() {
		return ordinal()+1;
	}
	
}

public class EnumDemos {

	public static void main(String[] args) {
		System.out.println(Day.Monday.ordinal());
	}
	
}
