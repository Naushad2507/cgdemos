package com.nau;

import java.util.logging.Logger;

class LoggerDemo {
	private static final Logger logger = Logger.getLogger("LoggerDemo");

	public void ld(int x) {
		logger.info("Inside LoggerDemo ld method");
		logger.info("The value of x from parameter is " + x);
		int z = (10 / x);
		System.out.println(z);
		logger.info("Exiting LoggerDemo ld method with x value " + z);
	}
}

public class ExpDemo {

	private static final Logger logger = Logger.getLogger("ExpDemo");

	public static void main(String[] args) {
		logger.info("Start");
		if(args.length<=1) {
			System.out.println("Please Enter a two numbers");
		}else {
			if(args[0].matches("[0-9]*") & args[1].matches("[0-9]*")){
				int n1 = Integer.parseInt(args[0]);
				int n2 = Integer.parseInt(args[1]);
				System.out.println(n1+n2);
			}else {
				System.out.println("Sorry , wrong number");
			}
		}
		logger.info("End of Application");
	}

}
