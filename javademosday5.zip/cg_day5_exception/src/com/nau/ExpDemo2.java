package com.nau;

import java.io.FileNotFoundException;
import java.util.logging.Logger;

public class ExpDemo2 {

	private static final Logger logger = Logger.getLogger("ExpDemo2");

	public static void main(String[] args) {
		logger.info("Start");

		try {
			String n1 = args[0];
			String n2 = args[1];
			System.out.println("N1 " + n1);
			System.out.println("N2 " + n2);
			if (n1.equals("123")) {
				throw new RuntimeException();
			}
			System.out.println(Integer.parseInt(n1) + (Integer.parseInt(n2)) / 0);

		} catch (ArrayIndexOutOfBoundsException e) {
//			String message = e.getMessage();
//			logger.severe(message);
//			logger.info(""+ e);
			System.out.println("AIOBE Message");
		} catch (NumberFormatException e) {
//			String message = e.getMessage();
//			logger.severe(message);
//			logger.info(""+ e);
			System.out.println("NFE Message");
		} catch (ArithmeticException e) {
//			String message = e.getMessage();
//			logger.severe(message);
//			logger.info(""+ e);
			System.out.println("AE Message");
		} catch (Exception e) {
			logger.severe("" + e);
		} finally {
			System.out.println("Finally Block");
		}
		logger.info("End of Application");
	}
}
