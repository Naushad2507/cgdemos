package com.nau;

import java.io.Closeable;

public class MyConnection implements Closeable{
	
	public MyConnection() {
		System.out.println("Connection Established");
	}
public void con() {
	System.out.println("con is going on");
}
	public void close() {
		System.out.println("conenction closed");
	}
}
