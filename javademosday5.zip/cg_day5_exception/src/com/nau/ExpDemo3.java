package com.nau;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ExpDemo3 {
	
	public static void main(String[] args) {
		System.out.println("Start");
		
		
		try {
			Thread.sleep(2);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		int x;
		{
			x = 40;
		}
		System.out.println(x);
		
		FileReader fileReader ;
		
		FileInputStream fis=null;
		
		try {
			fis = new FileInputStream("hello.txt");
			fileReader = new FileReader("asdf");
		} catch (FileNotFoundException e) {
			System.out.println("Ok, go and  read another book");
		}finally {
			if(fis!=null) {
				try {
					//fis.close();
					System.out.println("Closing files");
				} catch (Exception e) {
					System.out.println("IO EXP");
				}
			}
		}
		
		
		System.out.println("End");
		
		
	}

}
