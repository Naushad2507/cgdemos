package com.nau;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ExpDemo4 {
	
	public static void main(String[] args)  {
		System.out.println("Start");
		
		
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
		
		
		try(FileInputStream fis = new FileInputStream("hello.txt")){
			int x=0;
			while((x = fis.read())!=-1) {
				System.out.print((char)x);
			}
			Thread.sleep(1000);
			System.out.println();
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		} 
		
		try(MyConnection con = new MyConnection()){
			con.con();
			System.out.println("end of try resource");
		}
		
		
		System.out.println("End");
		
		
	}

}
