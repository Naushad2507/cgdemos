package com.nau.exp;

public class CalculatorDemo {
	public static void main(String[] args) {
		
		Calculator calculator = new Calculator();
		Employee e = new Employee("asd");
		
		int res = calculator.add(5, 2,e);
		System.out.println("Result : " + res);
	}
}
