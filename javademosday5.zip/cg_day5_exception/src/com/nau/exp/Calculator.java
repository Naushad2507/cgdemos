package com.nau.exp;

class Employee {
	private String name;

	public Employee() {
	}

	public Employee(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}

public class Calculator {

	private String name = null;
	int no = 0;

	public int add(int i, int j, Employee e) {
		System.out.println(e.getName());
		String name = e.getName();
		System.out.println(name.toUpperCase());
		return 0;
	}
}
