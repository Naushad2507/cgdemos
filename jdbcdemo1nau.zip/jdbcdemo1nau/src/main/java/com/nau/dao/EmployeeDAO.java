package com.nau.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Set;

import com.nau.model.Employee;
import com.nau.util.MyDBConnection;

public class EmployeeDAO {

	private Connection connection = MyDBConnection.getConnection();

	public Integer saveEmployee(Set<Employee> employees) {
		// persist the data;
		// database connection
		String sql = "insert into emp values(?,?)";
		try {
			PreparedStatement ps = connection.prepareStatement(sql);
			employees.forEach(e -> {
				try {
					ps.setInt(1, e.getId());
					ps.setString(2, e.getName());
					ps.executeUpdate();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			});
			ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

}
