package com.nau;

import com.nau.view.EmployeeView;

public class MainApp {
	
	public static void main(String[] args) {
		
		new EmployeeView();
		
	}

}
