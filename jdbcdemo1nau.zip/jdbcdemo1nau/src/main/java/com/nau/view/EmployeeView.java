package com.nau.view;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.nau.model.Employee;
import com.nau.service.EmployeeService;

public class EmployeeView {

	private Scanner scanner = new Scanner(System.in);
	private EmployeeService employeeService = new EmployeeService();

	public EmployeeView() {

		options();
		scanner.close();
	}

	private void options() {

		System.out.println("1. Add Employee");
		System.out.println("2. Delete Employee");
		System.out.println("5. Exit Application");

		System.out.println("Enter Choice : ");
		Integer choice = scanner.nextInt();

		switch (choice) {
		case 1: {
			addEmployee();
			options();
			break;
		}
		case 2: {
			deleteEmployee();
			options();
			break;
		}
		case 5: {
			System.out.println(".... Thank You ....");
			System.exit(0);
			break;
		}
		default: {
			System.out.println("Enter Option between 1 - 5");
			options();
		}
		}
	}

	private void deleteEmployee() {

	}

	private void addEmployee() {
		Set<Employee> employees = new HashSet<>();
		boolean ans = true;
		do {
			System.out.println("Enter ID:");
			Integer id = scanner.nextInt();
			System.out.println("Enter Name:");
			String name = scanner.next();
			employees.add(new Employee(id, name));
			System.out.println("Do you want to add More : Y/N");
			String resp = scanner.next().toLowerCase();
			if(resp.equals("n")) {
				ans = false;
			}
		} while (ans);
		String rvalue = employeeService.addEmployee(employees);
		System.out.println(rvalue);
		options();
	}

}
