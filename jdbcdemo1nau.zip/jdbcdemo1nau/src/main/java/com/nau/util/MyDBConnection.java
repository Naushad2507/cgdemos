package com.nau.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyDBConnection {
	private MyDBConnection() {
	}
	private static Connection connection;
	static {

		// 1? which database
		// ans : postgre
		try {
			// DriverManager.registerDriver(new Driver());// Postgres
			// jdbc:postgresql://server-name:server-port/database-name
			String dbname = "naushad";
			String url = "jdbc:postgresql://localhost:5432/" + dbname;
			String username = "postgres";
			String password = "admin";
			connection = DriverManager.getConnection(url, username, password);
			System.out.println("Connected");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static Connection getConnection() {
		return connection;
	}
}
