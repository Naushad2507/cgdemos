package cg_demos;

import com.naushad.CalculatorNaushad;

public class UseCalculator {
	
	public static void main(String[] args) {
		
		CalculatorNaushad calculatorNaushad = new CalculatorNaushad();
		calculatorNaushad.add(33);
		calculatorNaushad.sub(4);
		calculatorNaushad.add(44);
		int res = calculatorNaushad.getResult();
		System.out.println(res);
		
	}

}
