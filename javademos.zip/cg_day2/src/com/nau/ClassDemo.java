package com.nau;

public class ClassDemo {
	int x = 10; // instance variable
	int age;
	
	{
		System.out.println("asfd");
		System.out.println(3);
		System.out.println(true);
		// initializer block
		System.out.println("Init Block 1");
	}
	{
		// initializer block
		System.out.println("Init Block 2");
	}
	public ClassDemo() {
		System.out.println("Default constr");
	}
//	// Object
	public ClassDemo(int x) {
		System.out.println("CD 1 constructor");
	} // created by compiler

	public void cd1(int x) { // instance method
		System.out.println("cd1 method");

		if (x > 10) {
			return;  // break // continue
		} else {
			this.x = x;
		}
	}

	public int cd2() {
		System.out.println("cd2 method");
		x = 45;
		return x;
	}
	public int cd2(int x) {
		System.out.println("cd2 method");
		x = 45;
		return x;
	}
	public String cd2(String x) {
		System.out.println("cd2 method");
		x = "45";
		return "hello";
	}
	public boolean cd2(boolean x) {
		System.out.println("cd2 method");
		x = true;
		return x;
	}
	public float cd2(float x) {
		System.out.println("cd2 method");
		x = 45.9F;
		return x;
	}
}
