package com.nau;

class GDemo{
	static int x = 10;  // Class Variable
	public GDemo(int gd) {
		System.out.println("GDemo Object Created " + gd);
	}
	public static int square(int x) {
		return x*x;
	}
}

public class GlobalDemo {
	
	public static void main(String[] args) {
	//	GDemo demo1 = new GDemo(1);
		
		int r = Math.divideExact(16, 3);
		System.out.println(r);
		int sqr = GDemo.square(5);
		System.out.println(sqr);
		GDemo.x = 50;
		System.out.println(GDemo.x);
		
	//	GDemo demo2 = new GDemo(2);
		System.out.println(GDemo.x);
		GDemo.x= 5000;
		System.out.println(GDemo.x);
	}
}
