package com.nau;

class Student{
	int rollNo ;
	public Student(int rollNo) {
		this.rollNo = rollNo;
		System.out.println("Object Created with rollNo : " + this.rollNo);
	}
	@Override
	protected void finalize() throws Throwable {
		System.out.println("Object destroyed with rollno :" + this.rollNo);
	}
}

public class GarbageDemo {
	
	public static void main(String[] args) {
		
		Student s1=new Student(1);
		Student s2=new Student(2);
		s2 = s1;
		System.gc();
//		for (int i = 0; i < 100; i++) {
//			s = new Student(i);
//			System.gc();
//		}
		
//		System.out.println(" Roll No : " + s.rollNo);
//		System.out.println("Reaching End of Program");
//		
		
	}

}
