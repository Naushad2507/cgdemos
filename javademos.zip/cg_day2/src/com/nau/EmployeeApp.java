package com.nau;

public class EmployeeApp {

	public static void main(String[] args) {

		//System.out.println("Total Employee : " + Employee.getEmpCount());
		
		Employee e1 = new Employee();
		//System.out.println("Total Employee : " +Employee.getEmpCount());
//		e1.setEmpId(1);
//		e1.setEmpName("Naushad");
//		
		Employee e2 = new Employee();
//		e2.setEmpId(2);
//		e2.setEmpName("Akhtar");
//		
	//	Employee e3 = new Employee(3, "Rahul");
		System.out.println("Total Employee : " + Employee.getEmpCount());

//		
//		System.out.println(e1.getEmpName());
//		System.out.println(e2.getEmpName());
//		System.out.println(e3.getEmpName());
	}

}
