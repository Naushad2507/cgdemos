package com.nau;

public class Employee {

	private int empId;
	private String empName;
	private static int empCount;

	static{
		//System.out.println(empId);
		System.out.println("static block " + ++empCount);
	}
	
	{
		empCount++;
	}
	public static int getEmpCount() {
		//System.out.println(empId);
		return empCount;
	}
	public Employee() {
		System.out.println("Employee Created");
	}

	public Employee(int empId, String empName) {
		this.empId = empId;
		this.empName = empName;
		System.out.println("Employee Created");
	}

	

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

}
