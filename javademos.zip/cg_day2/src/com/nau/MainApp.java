package com.nau;
public class MainApp {
	public static void main(String[] args) {
	//	int x2  = 30; // primitive
		ClassDemo cd1 = new ClassDemo(3); // new instance / Object
		ClassDemo cd2 = new ClassDemo(); // new instance / Object
cd2.cd2(33);
		//cd1.age = 500;
		//	int xx = cd1.x;
		//System.out.println(xx);
		//cd1.x = 50;
	//	int yy = cd1.x;
	//	System.out.println(yy);
	//	cd1.cd1();
	//	cd1.cd2();
		cd1.cd1(6);
		System.out.println(cd1.x);
	//	new ClassDemo();
	}
}
