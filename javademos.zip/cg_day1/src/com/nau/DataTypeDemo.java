package com.nau;

import java.util.Scanner;

public class DataTypeDemo {
	
	public static void main(String[] args) {
		int x  = 30;
		String str = "hello";
		
		int i ;
		// data types
		// operators
		// looping construts
	
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter number 1");
		int n1 = scanner.nextInt();
		System.out.println("Enter number 1");
		int n2 = scanner.nextInt();
		System.out.println("Resutl is " + (n1+n2));
	
		var  y  =30;
		var aaa = "hello";
		var bbb = false;
		
		var z = 40;
		var ress = y+z;
		
		System.out.println(ress);
		// Integers
		byte a; // 1 byte // 256 / 127  :  -128
		a = 1;
		byte aa = 2;
		
		byte res = (byte)(a+aa);
		System.out.println(res);
		long l = 999999999999L; // 8 bytes
		
		short b=7; // 2 byte
		b= 5;
		
		int c =3;  // 4 byte
		c =6;
		c=666;
		System.out.println(c);
		long d;  // 8 byte
		d = 565655;
		
		// floating
		float e;  // 4 bytes
		e = 5656.77f; // 4 bytes
		System.out.println(e);
		double f; // 8 bytes
		// Boolean
		boolean g; // true/false
		g = false;
		if(g) {
			System.out.println("ok");
		}else {
			System.out.println("bad");
		}
		
		// Character
		char h; // 2 byte // ASCII 256 / 65536
		h = 'A';
//		int aa = h;
//		System.out.println(aa);
	}

}
