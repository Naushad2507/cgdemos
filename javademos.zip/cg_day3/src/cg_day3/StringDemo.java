package cg_day3;

class A extends Object{
	
}

public class StringDemo { //String Immutable Class

	public static void main(String[] args) {
		
		String s1 = "nau";
		String s2 = args[0].intern();
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s1==s2);
		System.out.println("======");
		
		
		int x = 4; // literal
		// string literal
		String a = "hello"; 
		String b = "hello";
		String cc = "HELLO";
		System.out.println(a==b);// reference
		System.out.println(a.equals(b));
		System.out.println(a);
		String au = a.toUpperCase();
		String pau = au.intern();
		System.out.println(a);
		System.out.println(cc==pau);
		System.out.println("===============");
		int xa = 10;
		int xb = 40;
		xa = xb;
		System.out.println(xa);
		
		String c = new String("helloboss"); //char[]
		String d = new String("helloboss");
		c=d;
		System.out.println(c==d);
		System.out.println(c.equals(d));
		System.out.println(d);
		String du = d.toUpperCase();
		System.out.println(d);
		System.out.println(du);
		
		
	}
}
