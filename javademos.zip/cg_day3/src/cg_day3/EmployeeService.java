package cg_day3;

// Service Class // Business Class
public class EmployeeService {

	public void add(Integer i, String number) {
		int pnumber = Integer.parseInt(number);
		// System.out.println(i+pnumber);
	}
 
	public void modifyEmployee(Employee employee) {
		System.out.println(employee);
		String name = employee.getName();
		String uname = name.toUpperCase();
		System.out.println(uname);
	}
 
	public void addEmployee(Employee employee) {
		
	}

}
