package cg_day3;
import java.lang.*;
// Model Class
public class Employee extends Object{
	
	private Integer id;
	private String name;
 
	public Employee() {
		// TODO Auto-generated constructor stub
	}
 
	public Employee(Integer id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + "]";
	}
}
// byte  // Byte
// short  // Short
// int  // Integer
// long // Long
// float // Float
// double //Double
// char // Character
// boolean// Boolean
