package cg_day3;

public class MainApp {
	
	public static void main(String[] args) {
		
		EmployeeService es = new EmployeeService();
		String name = "naushad";
		Employee employee =new Employee(1,name);
		es.modifyEmployee(employee);
		 
		//es.modifyEmployee(employee);
	
	}
//	public static void test(Integer i) {
//	//	int x = i.intValue();
//		System.out.println(i+i);
//	}

}
