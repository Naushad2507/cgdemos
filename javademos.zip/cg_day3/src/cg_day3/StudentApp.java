package cg_day3;

import java.util.Scanner;

public class StudentApp {
	
	public static void main(String[] args) {
		StudentService service = new StudentService();
		Scanner scanner = new Scanner(System.in);
		for(;;) {
			System.out.println("Enter Roll No : ");
			int rollNo = scanner.nextInt();
			System.out.println("Enter Name : " );
			String name = scanner.next();
			Student student = new Student(rollNo, name);
			service.addStudents(student);
			System.out.println("Do you want to Continue Y/N");
			String ans = scanner.next();
			if(ans.equalsIgnoreCase("y")) {
			}else {
				break;
			}
		}
		
		service.viewAllStudents();
	}

}
