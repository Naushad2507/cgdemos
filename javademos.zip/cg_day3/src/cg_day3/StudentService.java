package cg_day3;

public class StudentService {
	private Student studentsTable[] = new Student[100];
	{
		studentsTable[0] = new Student(1, "Naushad");
		studentsTable[1] = new Student(2, "Akhtar");
	}

	public int checkStudentCount() {
		int countOfStudents = 0;
		for (Student student : studentsTable) {
			if (student != null) {
				countOfStudents++;
			}
		}
		System.out.println("Total Student : " + countOfStudents);
		return countOfStudents;
	}

	public void addStudents(Student... students) {
		int totalStudents = checkStudentCount(); // 2
		for (Student s : students) {
			studentsTable[totalStudents] = s;
			totalStudents++;
		}
	}

	public void viewAllStudents() {
		for (Student student : studentsTable) {
			if (student != null)
				System.out.println(student);
		}
	}
}
