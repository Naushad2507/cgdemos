package cg_day3;

public class ArrayDemo {

	public static void main(String[] args) {
		int size = Integer.parseInt(args[0]);

		int y[] = { 11, 22, 33, 44, 55, 66 };
		// display(y);

		int[] z = { 2, 3 };
		z[1] = 4;
		// display(z);
		int k[] = new int[10];
		// display(k);
		k[4] = 50;
		// display(k);

		String s1, s2, s3, s4, s5;
		String s[] = new String[5];
		String names[] = { "nau", "akh", "rahul" };
		// String sn = names[0]; // nau
		names[0] = names[0].toUpperCase();
		// displayNames(names);
//		for(int j=0;j<names.length;j++) {
//			String name = names[j];
//			System.out.println(name);
//			names[j] = name.toUpperCase()+"wow";
//			System.out.println(names[j]);
//		}
//		for(String name : names) {
//			System.out.println(name);
//		}
		int[] x = new int[5];
		x[0] = 0;
		x[1] = 11;
		x[2] = 22;
		x[3] = 33;
		x[4] = 44;

		int xx = 50;
//		display("ab");
//		display("xy",x);
//		display("nm",xx);
//		display("po",1,2,3);
		Employee employee1 = new Employee(4, "Parul");
		Employee employee2 = new Employee(5, "Akash");
		Employee employees[] = new Employee[5];

		employees[0] = new Employee(1, "RAhul");
		employees[1] = new Employee(2, "Ajay");
		employees[2] = new Employee(3, "Baba");
		employees[3] = employee1;
		displayEmployees();
	}

	public static void displayEmployees(Employee... employees) {
		System.out.println(" ID " + "\tName " );
		for(Employee employee : employees) {
			System.out.println(employee);
			System.out.println(employee.getId() + "\t " + employee.getName());
		}
	}

	public static void display(String name, int... i) { // VAR ARGS
		System.out.println(name);
		System.out.println("Length : " + i.length);
		for (int j = 0; j < i.length; j++) {
			System.out.println(i[j]);
		}
	}

	public static void displayNames(String names[]) {
		System.out.println(names.length);
//		for(int j=0;j<names.length;j++) {
//			String name = names[j];
//			names[j] = name.toUpperCase()+"wow";
//			System.out.println(names[j]);
//		}
		for (String name : names) {
			// name = name.toUpperCase()+"wow";
			System.out.println(name);
		}
	}

	public static void displayE(Employee e) {
		e.setName("akhtar");
	}

	public static void displayA(int i) {
		// System.out.println(i);
		i = 50;
	}

}

//System.out.println(x[2]);
//display(x);
//System.out.println(x[2]);

//int i = 20;
//System.out.println(i);
//displayA(i);
//System.out.println(i);	
//Employee e1 = new Employee(1, "naushad");
//System.out.println(e1);
//displayE(e1);
//System.out.println(e1);
