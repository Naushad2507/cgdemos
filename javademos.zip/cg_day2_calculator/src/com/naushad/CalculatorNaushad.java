package com.naushad;

public class CalculatorNaushad {
	
	private int result;
	
	public void add(int a) {
		this.result = this.result + a;
	}
	public void sub(int a) {
		this.result = this.result - a;
	}
	public int getResult() {
		return this.result;
	}
}
