
package com.naushad;

public class UseTV {

	public static void main(String[] args) {

		TVRemote tv = new LGTV();
		operateTV(tv);
	}

	public static void operateTV(TVRemote tv) {
		tv.on();
		tv.off();
		tv.brand();
	}

}
