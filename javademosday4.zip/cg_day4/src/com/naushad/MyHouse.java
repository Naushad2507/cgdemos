package com.naushad;

public  class MyHouse extends House{
	
	@Override
	public void kitchen() {
		System.out.println("Kitchen");
	}
	
	public void bathRoom() {
		System.out.println("bathroom");
	}
	
	@Override
	public void bedRoom() {
		System.out.println("Master with LED TV");
	}
	
}
