package com.naushad;

public class LGTV implements TVRemote {

	@Override
	public void on() {
		System.out.println("LG TV On");
	}

	@Override
	public void off() {
		System.out.println("LG TV Off");
	}

	@Override
	public void brand() {
		System.out.println("LG TV Brand");

	}

}
