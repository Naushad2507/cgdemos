package com.naushad;


// Abstract Classes
public abstract class House extends Object{
	
	private int x = 40;
	
	public House() {
	}
	public void garden() {
		System.out.println("MY Garden");
	}
	public void parking() {
		System.out.println("Parking Lot");
	}
	public void livingRoom() {
		System.out.println("Living Room");
	}
	public void bedRoom() {
		System.out.println("Master Bedroom");
	}
	public abstract void kitchen();
	public abstract void bathRoom();
}
