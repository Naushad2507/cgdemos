package com.naushad;

public  interface TVRemote {
	
	void on();
	void off();
	void brand();

}
