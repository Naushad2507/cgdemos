package com.naushad;

public class HouseApp {

	public static void main(String[] args) {

		House h = new MyHouse();
		h.bedRoom();

	}

}
