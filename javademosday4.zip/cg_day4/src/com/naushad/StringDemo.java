package com.naushad;

import java.util.regex.Pattern;

public class StringDemo {
	
	public static void main(String[] args) {
//		String email = "aa@cc.@com";// validation logic
//		String pattern = "^(.+)@(.+)$";
//		System.out.println(email.matches(pattern));
//		boolean b = Pattern.matches(pattern, email);
//		System.out.println(b);
		String p = "[A-Z]{5,5}[0-9]{4,4}[A-Z]{1,1}";
		String pan = "ABCDE1234A";
		boolean pa = pan.matches(p);
		System.out.println(pa);
		
	//	StringBuilder
	//	StringBuffer
		StringBuilder builder = new StringBuilder("hello");// Not Synchronized
		System.out.println(builder);
		builder.append("world");
		System.out.println(builder);
		
		StringBuffer buffer = new StringBuffer("hello"); // Synchronized
		System.out.println(buffer);
		buffer.append("world");
		System.out.println(buffer);
	}

}
