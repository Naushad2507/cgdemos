package com.naushad;

public class SamsungTv implements TVRemote{

	@Override
	public void on() {
		System.out.println("Samsung Tv ON");
	}

	@Override
	public void off() {
		System.out.println("Samsung Tv OFF");
	}

	@Override
	public void brand() {
		System.out.println("Samsung Brand ");
	}

}
