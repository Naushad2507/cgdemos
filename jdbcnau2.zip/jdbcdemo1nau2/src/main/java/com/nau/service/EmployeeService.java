package com.nau.service;

import java.util.List;
import java.util.Set;

import com.nau.dao.EmployeeDAO;
import com.nau.model.Employee;

public class EmployeeService {
	
	private EmployeeDAO employeeDAO = new EmployeeDAO();
	
	public String addEmployee(Set<Employee> employees) {
		
		// convert employee names to upper case and than send 
		
		employeeDAO.saveEmployee(employees);
		
		return "added";
	}
	

}
