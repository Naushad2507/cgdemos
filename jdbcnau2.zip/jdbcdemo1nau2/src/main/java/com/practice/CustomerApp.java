package com.practice;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Iterator;

public class CustomerApp {

	public static void main(String[] args) {
		System.out.println(args.length);
		// Customer customer = new Customer(6, "naushad", "kerala");
		// saveCustomer(customer);
		// updateCustomer(customer);
		// deleteCustomer(2);
		//Customer customer2 = viewCustomer(6);
		
	//	System.out.println(customer2);
		Customer customers[] = viewAllCustomers();
		if(customers==null) {
			System.out.println("No DATA");
		}else {
			displayCustomers(customers);
		}
	}

	private static void displayCustomers(Customer... customers) {// List
			System.out.println("ID " + "\t" + "Name " + "\t" + "City ");
			for (Customer customer : customers) {
				System.out.println(customer.getId() + "\t" + customer.getName() + "\t" + customer.getCity());
			}
	}

	private static Customer[] viewAllCustomers() {
		String sql = "select * from customer";
		Connection con = DBCon.getCon();
		try (PreparedStatement ps = con.prepareStatement(sql,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY)) {
			//System.out.println(id);
			ResultSet resultSet = ps.executeQuery();
		//	ResultSetMetaData metaData = resultSet.getMetaData();
			resultSet.last();
			int rowCount = resultSet.getRow();
			Customer customers[] = new Customer[rowCount];
			resultSet.first();
			while(resultSet.next()) {
				for (int i = 0; i < rowCount; i++) {
					Integer idr = resultSet.getInt(1);
					String namer = resultSet.getString(2);
					String cityr = resultSet.getString(3);
					customers[i] = new  Customer(idr, namer, cityr);
				}
			}
			return customers;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}

	private static Customer viewCustomer(int id) {
		String sql = "select * from customer where id=?";
		Connection con = DBCon.getCon();
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setInt(1, id);
			//System.out.println(id);
			ResultSet resultSet = ps.executeQuery();
			if (resultSet.next()) {
				System.out.println("next");
				String namer = resultSet.getString(2);
				String cityr = resultSet.getString(3);
				return new Customer(id, namer, cityr);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;

	}

	private static void deleteCustomer(int id) {

	}

	private static void updateCustomer(Customer customer) {
		String sql = "update customer set city=? where id=?";
		Connection con = DBCon.getCon();
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, customer.getCity());
			ps.setInt(2, customer.getId());
			int res = ps.executeUpdate();
			System.out.println(res);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static void saveCustomer(Customer customer) {
		Integer id = customer.getId();
		String name = customer.getName().toUpperCase();
		String city = customer.getCity();

		String sql = "insert into customer values(?,?,?)";
		Connection con = DBCon.getCon();
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setInt(1, id);
			ps.setString(2, name);
			ps.setString(3, city);
			int res = ps.executeUpdate();
			System.out.println(res);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
