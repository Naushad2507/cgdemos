package com.practice;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBCon {
	private DBCon() {
	}

	static Connection con;
	static {
		try {
			// Class.forName("org.postgresql.Driver"); // Reflection
			// DriverManager.registerDriver(new Driver());
			// System.out.println("Driver Loaed");
			String url = "jdbc:postgresql://localhost:5432/capgemini";
			String username = "postgres";
			String password = "admin";
			con = DriverManager.getConnection(url, username, password);
			
			System.out.println("connected");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static Connection getCon() {
		return con;
	}
}
